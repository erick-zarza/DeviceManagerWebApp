terraform {
  backend "s3" {
    bucket         = "edp-data-catalog-terraform-state-bucket"
    key            = "terraform.tfstate"
    region         = "us-west-2"
    dynamodb_table = "edp-data-catalog-terraform-locks"
    role_arn       = "arn:aws:iam::782492290385:role/edp-data-catalog-terraform-state-management-role"
  }
}