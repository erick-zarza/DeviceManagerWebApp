terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.62"
    }
  }
}

provider "aws" {
  region = "us-west-2"

  default_tags {
    tags = {
      admin_contact = "edp.admin"
      service_data  = "env=${var.env_type}"
      service_id    = "EDP"
    }
  }
}
