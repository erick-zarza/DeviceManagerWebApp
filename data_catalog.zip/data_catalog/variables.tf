variable "product" {
  description = "Name of the Data Product"
  type        = string
  default     = "migration"
}

variable "project" {
  description = "Name of the Project"
  type        = string
  default     = "edp"
}

variable "env_type" {
  description = "Environment"
  type        = string
  default     = "dev"
}

variable "redshift_type" {
  type        = string
  description = "Set AWS Redshift Deployment Type. Options: redshift-serverless, redshift-cluster"
  default     = "redshift-cluster"
  validation {
    condition     = contains(["redshift-serverless", "redshift-cluster"], var.redshift_type)
    error_message = "Valid values for redshift_type are (redshift-serverless, redshift-cluster)"
  }
}

variable "master_user" {
  type        = string
  description = "Redshift Cluster Database Master User Name"
  default     = "edpadmin"
}

variable "master_password" {
  type        = string
  description = "Redshift Cluster Database Master Password"
  default     = "Adfalj#bla1h!afodif"
  sensitive   = true
}

variable "redshift_connection_subnet_az" {
  type        = string
  description = "Redshift Connection Subnet Availability Zone"
  default     = "us-west-2a"
}

variable "data_sources" {
  type        = list(string)
  description = "Data Catalog Data sources"
  default     = ["oud", "qsales", "marketo", "aanalytics", "qcterp", "demantra", "qctfindw", "sixsense", "accutics", "datorama", "gtmda", "edp"]
}

variable "transform_features" {
  type        = list(string)
  description = "Transform Features"
  default     = ["bu-segmentation"]
}

variable "s3_bucket_versioning" {
  description = "S3 Bucket Versioning"
  type        = string
  default     = "Enabled"
}

variable "region" {
  description = "AWS Region"
  type        = string
  default     = "us-west-2"
}

variable "vpc_id" {
  description = "Security Group VPC Id"
  type        = string
  default     = "vpc-093d08828aa097f03"
}

variable "subnet_id" {
  description = "Subnets Configuration List"
  type        = string
  default     = "subnet-0c5de35600d539fd0"
}

variable "recrawl_behavior" {
  description = "Recrawl Behavior"
  type        = string
  default     = "CRAWL_EVERYTHING"
}

variable "delete_behavior" {
  description = "Delete Behavior"
  type        = string
  default     = "DEPRECATE_IN_DATABASE"
}

variable "update_behavior" {
  description = "Update Behavior"
  type        = string
  default     = "UPDATE_IN_DATABASE"
}

variable "glue_version" {
  description = "Glue version"
  type        = string
  default     = "4.0"
}

variable "worker_type" {
  description = "Worker Type"
  type        = string
  default     = "G.4X"
}

variable "number_of_workers" {
  description = "Number of Workers"
  type        = number
  default     = 20
}

variable "max_retries" {
  description = "Max Retries"
  type        = number
  default     = 0
}

variable "timeout" {
  description = "Timeout"
  type        = number
  default     = 120
}

variable "python_version" {
  description = "Python Version"
  type        = string
  default     = "3"
}

variable "command_name" {
  description = "Command Name"
  type        = string
  default     = "glueetl"
}

variable "enable_auto_scaling" {
  description = "Enable Auto Scaling"
  type        = string
  default     = "true"
}

variable "max_concurrent_runs" {
  description = "Max Concurrent Runs"
  type        = number
  default     = 20
}

variable "jdbc_enforce_ssl" {
  description = "Jdbc Enforce Ssl"
  type        = bool
  default     = false
}
