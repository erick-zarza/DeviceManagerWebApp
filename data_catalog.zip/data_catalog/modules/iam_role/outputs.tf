output "role_arn" {
  description = "ARN of the IAM Role"
  value       = module.iam_role.role_arn
}