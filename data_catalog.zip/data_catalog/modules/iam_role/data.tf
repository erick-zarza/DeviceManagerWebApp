data "aws_iam_policy_document" "aggregated_policy_document" {
  statement {
    effect = "Allow"
    actions = [
      "rds:DescribeDBSubnetGroups",
      "rds:DescribeDBClusters"
    ]
    resources = [
      "*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "dynamodb:PutItem",
      "dynamodb:UpdateItem",
      "dynamodb:DescribeTable",
      "dynamodb:GetItem",
      "dynamodb:UpdateTable",
      "dynamodb:GetRecords"
    ]
    resources = [
      "arn:aws:dynamodb:${var.region}:${local.account_id}:table/${var.project}-job-control-${var.env_sfx_l}",
      "arn:aws:dynamodb:${var.region}:${local.account_id}:table/${var.project}-job-log-${var.env_sfx_l}"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "s3:PutObject",
      "s3:GetObjectAcl",
      "s3:GetObject",
      "s3:DeleteObject",
      "s3:GetBucketPolicy",
      "s3:ReplicateDelete",
      "s3:ListBucket",
      "s3:ListMultipartUploadParts"
    ]
    resources = [
      "arn:aws:s3:::${var.project}-datalake-raw-${var.env_sfx_l}/*",
      "arn:aws:s3:::${var.project}-datalake-raw-${var.env_sfx_l}",
      "arn:aws:s3:::${var.project}-datalake-int-${var.env_sfx_l}/*",
      "arn:aws:s3:::${var.project}-datalake-int-${var.env_sfx_l}",
      "arn:aws:s3:::${var.project}-datalake-pub-${var.env_sfx_l}/*",
      "arn:aws:s3:::${var.project}-datalake-pub-${var.env_sfx_l}",
      "arn:aws:s3:::${var.project}-datalake-err-${var.env_sfx_l}/*",
      "arn:aws:s3:::${var.project}-datalake-err-${var.env_sfx_l}",
      "arn:aws:s3:::${var.project}-datalake-enr-${var.env_sfx_l}/*",
      "arn:aws:s3:::${var.project}-datalake-enr-${var.env_sfx_l}",
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "s3:GetObject",
    ]
    resources = [
      "arn:aws:s3:::${var.project}-glue-artifacts-${var.env_sfx_l}/*",
      "arn:aws:s3:::${var.project}-glue-artifacts-${var.env_sfx_l}"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "glue:*",
      "s3:GetBucketLocation",
      "s3:ListBucket",
      "s3:ListAllMyBuckets",
      "s3:GetBucketAcl",
      "ec2:DescribeVpcEndpoints",
      "ec2:DescribeRouteTables",
      "ec2:CreateNetworkInterface",
      "ec2:DeleteNetworkInterface",
      "ec2:DescribeNetworkInterfaces",
      "ec2:DescribeSecurityGroups",
      "ec2:DescribeSubnets",
      "ec2:DescribeVpcAttribute",
      "iam:ListRolePolicies",
      "iam:GetRole",
      "iam:GetRolePolicy",
      "cloudwatch:PutMetricData"
    ]
    resources = [
      "*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "s3:CreateBucket"
    ]
    resources = [
      "arn:aws:s3:::aws-glue-*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "s3:GetObject",
      "s3:PutObject",
      "s3:DeleteObject"
    ]
    resources = [
      "arn:aws:s3:::aws-glue-*/*",
      "arn:aws:s3:::*/*aws-glue-*/*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "s3:GetObject"
    ]
    resources = [
      "arn:aws:s3:::crawler-public*",
      "arn:aws:s3:::aws-glue-*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:PutLogEvents"
    ]
    resources = [
      "arn:aws:logs:*:*:/aws-glue/*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "ec2:CreateTags",
      "ec2:DeleteTags"
    ]
    resources = [
      "arn:aws:ec2:*:*:network-interface/*",
      "arn:aws:ec2:*:*:security-group/*",
      "arn:aws:ec2:*:*:instance/*"
    ]
    condition {
      test     = "ForAllValues:StringEquals"
      variable = "aws:TagKeys"
      values   = ["aws-glue-service-resource"]
    }
  }

  statement {
    effect = "Allow"
    actions = [
      "kms:Decrypt",
      "kms:Encrypt",
      "kms:GenerateDataKey",
      "kms:DescribeKey",
      "kms:ReEncrypt"
    ]
    resources = [
      # "{Fn.import_value('datalake-key-arn-' + env_sfx_l)}"
      # data.aws_cloudformation_export.subnet_id.value
      "*" # TODO: Fix
    ]
  }
}

#TODO: Get real values from real account
data "aws_cloudformation_export" "subnet_id" {
  # name = "datalake-key-arn-${var.env_sfx_l}"
  name = "CdkBootstrap-hnb659fds-FileAssetKeyArn"
}

data "aws_iam_policy_document" "assume_policy_document" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["glue.amazonaws.com"]
    }
  }
}

# Get the current AWS account ID
data "aws_caller_identity" "current" {}
