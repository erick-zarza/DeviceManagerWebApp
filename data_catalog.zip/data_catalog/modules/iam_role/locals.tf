locals {
  role_name          = "glue-execution"
  role_description   = "EDP Glue role to access S3 buckets, RDS databases and DynamoDB tables"
  policy_name        = "s3-rds-dynamodb"
  policy_description = "EDP Policy for Glue role to access S3 buckets, RDS databases and DynamoDB tables"
  account_id         = data.aws_caller_identity.current.account_id
}
