module "iam_role" {
  source             = "../../../../common_modules/common_iam_role"
  project            = var.project
  product            = var.product
  env_sfx_l          = var.env_sfx_l
  role_name          = local.role_name
  role_description   = local.role_description
  policy_name        = local.policy_name
  policy_description = local.policy_description

  policy_documents        = [data.aws_iam_policy_document.aggregated_policy_document.json]
  assume_policy_documents = [data.aws_iam_policy_document.assume_policy_document.json]
}
