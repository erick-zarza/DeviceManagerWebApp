variable "product" {
  description = "Name of the Data Product"
  type        = string
}

variable "project" {
  description = "Name of the Project"
  type        = string
}

variable "env_sfx_l" {
  description = "Environment Type Lower Case"
  type        = string
}

variable "vpc_id" {
  description = "Security Group VPC Id"
  type        = string
}
