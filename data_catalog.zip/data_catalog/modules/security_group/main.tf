resource "aws_security_group" "glue_security_group" {
  name        = "${var.project}-${var.product}-glue-security-group-${var.env_sfx_l}"
  vpc_id      = var.vpc_id
  description = "Security group created to control traffic for EDP Glue environment"
}

resource "aws_vpc_security_group_egress_rule" "allow_all_traffic_ipv4" {
  description       = "Allow all outbound traffic by default"
  security_group_id = aws_security_group.glue_security_group.id
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1" # semantically equivalent to all ports
}

resource "aws_security_group_rule" "glue_security_group_self_referencing" {
  type              = "ingress"
  from_port         = 0
  to_port           = 0
  protocol          = "-1"
  self              = true
  security_group_id = aws_security_group.glue_security_group.id

  description = "Self referencing rule for security group"
}
