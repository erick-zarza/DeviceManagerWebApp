output "glue_security_group_id" {
  description = "Glue Security Group Id"
  value       = aws_security_group.glue_security_group.id
}
