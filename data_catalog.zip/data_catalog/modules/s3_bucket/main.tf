resource "aws_s3_bucket" "glue_artifacts_bucket" {
  bucket = "${var.project}-${var.product}-glue-artifacts-${var.env_sfx_l}"
}

resource "aws_s3_bucket_versioning" "versioning_example" {
  bucket = aws_s3_bucket.glue_artifacts_bucket.id
  versioning_configuration {
    status = var.s3_bucket_versioning
  }
}
