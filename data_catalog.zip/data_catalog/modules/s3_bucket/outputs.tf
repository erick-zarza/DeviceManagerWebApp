output "glue_s3_bucket_id" {
  description = "Glue Security Group Id"
  value       = aws_s3_bucket.glue_artifacts_bucket.id
}
