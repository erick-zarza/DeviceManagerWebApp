data "aws_caller_identity" "current" {}

data "aws_redshift_cluster" "example" {
  cluster_identifier = "${var.project}-${var.product}-redshift-cluster-${var.env_sfx_l}"
}
