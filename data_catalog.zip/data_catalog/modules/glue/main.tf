resource "aws_glue_connection" "edp-glue-redshift-connection-dev" {
  name       = "${var.project}-${var.product}-glue-redshift-connection-${var.env_sfx_l}"
  catalog_id = data.aws_caller_identity.current.account_id
  connection_properties = {
    "JDBC_CONNECTION_URL" = local.JDBC_CONNECTION_URL
    "JDBC_ENFORCE_SSL"    = var.jdbc_enforce_ssl
    "USERNAME"            = var.master_user
    "PASSWORD"            = var.master_password
  }
  description = "Connection for glue jobs to access database objects in Redshift cluster"
  physical_connection_requirements {
    availability_zone      = var.redshift_connection_subnet_az
    security_group_id_list = [var.security_group_id]
    subnet_id              = var.subnet_id
  }
}

resource "aws_glue_catalog_database" "redshift_glue_database" {
  name         = "${var.project}-${var.product}-redshift-db-${var.env_sfx_l}"
  location_uri = "-"
  description  = "Database for Glue Crawler which runs on the GTM Data Lake in Redshift"
  catalog_id   = data.aws_caller_identity.current.account_id
}

resource "aws_glue_crawler" "redshift_crawler" {
  name          = "${var.project}-${var.product}-redshift-crawler-${var.env_sfx_l}"
  role          = var.role_arn
  database_name = aws_glue_catalog_database.redshift_glue_database.name
  description   = "Glue Crawler for Redshift data sources"

  dynamic "jdbc_target" {
    for_each = var.data_sources

    content {
      connection_name = aws_glue_connection.edp-glue-redshift-connection-dev.name
      path            = "${var.project}-${var.product}${var.env_sfx_l}/${jdbc_target.value}/"
    }
  }

  recrawl_policy {
    recrawl_behavior = var.recrawl_behavior
  }

  schema_change_policy {
    delete_behavior = var.delete_behavior
    update_behavior = var.update_behavior
  }
}

# Provision Data Lake ENR Glue Database
resource "aws_glue_catalog_database" "datalake_enr_glue_database" {
  for_each     = toset(var.transform_features)
  name         = "${var.project}-${var.product}-datalake-enr-${each.value}-db-${var.env_sfx_l}"
  location_uri = "-"
  description  = "Database for Glue Crawler which runs on the GTM Data Lake for {feature}"
  catalog_id   = data.aws_caller_identity.current.account_id
}

# Provision Data Lake ENR Crawler
resource "aws_glue_crawler" "datalake_enr_crawler" {
  for_each      = toset(var.transform_features)
  name          = "${var.project}-${var.product}-datalake-enr-${each.value}-crawler-${var.env_sfx_l}"
  role          = var.role_arn
  database_name = aws_glue_catalog_database.datalake_enr_glue_database[each.key].name
  description   = "Glue Crawler which runs on the GTM Data Lake for ${each.value}"

  s3_target {
    path = "s3://${var.glue_s3_bucket_id}/transform=${each.key}"
  }

  configuration = <<EOF
  {
    "Version": 1.0,
    "Grouping": {
      "TableGroupingPolicy": "CombineCompatibleSchemas",
      "TableLevelConfiguration": 4
    }
  }
  EOF

  recrawl_policy {
    recrawl_behavior = var.recrawl_behavior
  }

  schema_change_policy {
    delete_behavior = var.delete_behavior
    update_behavior = var.update_behavior
  }
}

# Provision Preprocessing Job
resource "aws_glue_job" "preprocessing_job" {
  name              = "${var.project}-${var.product}_preprocessing_glue_job-${var.env_sfx_l}"
  role_arn          = var.role_arn
  glue_version      = var.glue_version
  worker_type       = var.worker_type
  number_of_workers = var.number_of_workers
  max_retries       = var.max_retries
  timeout           = var.timeout

  command {
    script_location = "s3://${var.glue_s3_bucket_id}/glue_jobs/${var.project}-${var.product}_preprocessing_glue_job.py"
    python_version  = var.python_version
    name            = var.command_name
  }

  default_arguments = {
    "--extra-py-files"      = "s3://${var.glue_s3_bucket_id}/utils.zip"
    "--enable-auto-scaling" = var.enable_auto_scaling
  }

  execution_property {
    max_concurrent_runs = var.max_concurrent_runs
  }
}

# Provision CDC Job
resource "aws_glue_job" "cdc_job" {
  name              = "${var.project}-${var.product}_cdc_glue_job-${var.env_sfx_l}"
  role_arn          = var.role_arn
  glue_version      = var.glue_version
  worker_type       = var.worker_type
  number_of_workers = var.number_of_workers
  max_retries       = var.max_retries
  timeout           = var.timeout

  command {
    script_location = "s3://${var.glue_s3_bucket_id}/glue_jobs/${var.project}-${var.product}_cdc_glue_job.py"
    python_version  = var.python_version
    name            = var.command_name
  }

  default_arguments = {
    "--extra-py-files"      = "s3://${var.glue_s3_bucket_id}/utils.zip"
    "--enable-auto-scaling" = var.enable_auto_scaling
  }

  execution_property {
    max_concurrent_runs = var.max_concurrent_runs
  }
}

# Provision Field Mapping Job
resource "aws_glue_job" "field_mapping_job" {
  name              = "${var.project}-${var.product}_field_mapping_glue_job-${var.env_sfx_l}"
  role_arn          = var.role_arn
  glue_version      = var.glue_version
  worker_type       = var.worker_type
  number_of_workers = var.number_of_workers
  max_retries       = var.max_retries
  timeout           = var.timeout

  command {
    script_location = "s3://${var.glue_s3_bucket_id}/glue_jobs/${var.project}-${var.product}_field_mapping_glue_job.py"
    python_version  = var.python_version
    name            = var.command_name
  }

  default_arguments = {
    "--extra-py-files"      = "s3://${var.glue_s3_bucket_id}/utils.zip"
    "--enable-auto-scaling" = var.enable_auto_scaling
  }

  execution_property {
    max_concurrent_runs = var.max_concurrent_runs
  }
}

# Provision Redshift Load Job
resource "aws_glue_job" "redshift_load_job" {
  name              = "${var.project}-${var.product}_datalake_redshift_load_glue_job-${var.env_sfx_l}"
  role_arn          = var.role_arn
  glue_version      = var.glue_version
  worker_type       = var.worker_type
  number_of_workers = var.number_of_workers
  max_retries       = var.max_retries
  timeout           = var.timeout

  command {
    script_location = "s3://${var.glue_s3_bucket_id}/glue_jobs/${var.project}-${var.product}_datalake_redshift_load_glue_job.py"
    python_version  = var.python_version
    name            = var.command_name
  }

  default_arguments = {
    "--extra-py-files"      = "s3://${var.glue_s3_bucket_id}/utils.zip"
    "--enable-auto-scaling" = var.enable_auto_scaling
  }

  execution_property {
    max_concurrent_runs = var.max_concurrent_runs
  }

  connections = [aws_glue_connection.edp-glue-redshift-connection-dev.name]
}
