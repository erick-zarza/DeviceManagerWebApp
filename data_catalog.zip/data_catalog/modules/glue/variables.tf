variable "product" {
  description = "Name of the Data Product"
  type        = string
}

variable "project" {
  description = "Name of the Project"
  type        = string
}

variable "env_sfx_l" {
  description = "Environment Type Lower Case"
  type        = string
}

variable "vpc_id" {
  description = "Security Group VPC Id"
  type        = string
}

variable "glue_s3_bucket_id" {
  description = "Glue S3 Bucket Id"
  type        = string
}

variable "role_arn" {
  description = "Glue Role Arn"
  type        = string
}

variable "security_group_id" {
  description = "Security Group Id"
  type        = string
}

variable "master_user" {
  type        = string
  description = "Redshift Cluster Database Master User Name"
}

variable "master_password" {
  type        = string
  description = "Redshift Cluster Database Master Password"
  sensitive   = true
}

variable "data_sources" {
  type        = list(string)
  description = "Data Catalog Data sources"
}

variable "transform_features" {
  type        = list(string)
  description = "Transform Features"
}

variable "redshift_connection_subnet_az" {
  type        = string
  description = "Redshift Connection Subnet Availability Zone"
}

variable "subnet_id" {
  description = "Subnets Configuration List"
  type        = string
}

variable "recrawl_behavior" {
  description = "Recrawl Behavior"
  type        = string
}

variable "delete_behavior" {
  description = "Delete Behavior"
  type        = string
}

variable "update_behavior" {
  description = "Update Behavior"
  type        = string
}

variable "glue_version" {
  description = "Glue version"
  type        = string
}

variable "worker_type" {
  description = "Worker Type"
  type        = string
}

variable "number_of_workers" {
  description = "Number of Workers"
  type        = number
}

variable "max_retries" {
  description = "Max Retries"
  type        = number
}

variable "timeout" {
  description = "Timeout"
  type        = number
}

variable "python_version" {
  description = "Python Version"
  type        = string
}

variable "command_name" {
  description = "Command Name"
  type        = string
}

variable "enable_auto_scaling" {
  description = "Enable Auto Scaling"
  type        = string
}

variable "max_concurrent_runs" {
  description = "Max Concurrent Runs"
  type        = number
}

variable "jdbc_enforce_ssl" {
  description = "Jdbc Enforce Ssl"
  type        = bool
}
