data "aws_vpc" "edp_vpc" {
  id = var.vpc_id
}
