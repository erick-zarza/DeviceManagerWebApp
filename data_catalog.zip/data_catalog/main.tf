module "utilities" {
  source   = "../../common_modules/common_utilities"
  env_type = var.env_type
}

module "iam_role" {
  source    = "./modules/iam_role"
  project   = var.project
  product   = var.product
  env_sfx_l = module.utilities.env_sfx_l
  region    = var.region
}

module "security_group" {
  source    = "./modules/security_group"
  vpc_id    = data.aws_vpc.edp_vpc.id
  product   = var.product
  project   = var.project
  env_sfx_l = module.utilities.env_sfx_l
}

module "s3_bucket" {
  source               = "./modules/s3_bucket"
  product              = var.product
  project              = var.project
  env_sfx_l            = module.utilities.env_sfx_l
  s3_bucket_versioning = var.s3_bucket_versioning
}

module "glue" {
  source                        = "./modules/glue"
  product                       = var.product
  project                       = var.project
  env_sfx_l                     = module.utilities.env_sfx_l
  vpc_id                        = var.vpc_id
  glue_s3_bucket_id             = module.s3_bucket.glue_s3_bucket_id
  role_arn                      = module.iam_role.role_arn
  security_group_id             = module.security_group.glue_security_group_id
  master_user                   = var.master_user
  master_password               = var.master_password
  data_sources                  = var.data_sources
  transform_features            = var.transform_features
  redshift_connection_subnet_az = var.redshift_connection_subnet_az
  subnet_id                     = var.subnet_id
  recrawl_behavior              = var.recrawl_behavior
  delete_behavior               = var.delete_behavior
  update_behavior               = var.update_behavior
  glue_version                  = var.glue_version
  worker_type                   = var.worker_type
  number_of_workers             = var.number_of_workers
  max_retries                   = var.max_retries
  timeout                       = var.timeout
  python_version                = var.python_version
  command_name                  = var.command_name
  enable_auto_scaling           = var.enable_auto_scaling
  max_concurrent_runs           = var.max_concurrent_runs
  jdbc_enforce_ssl              = var.jdbc_enforce_ssl
}


