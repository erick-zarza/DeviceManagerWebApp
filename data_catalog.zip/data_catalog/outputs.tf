# output "redshift_serverless_endpoint" {
#   value = length(module.redshift_serverless) > 0 ? module.redshift_serverless[*].redshift_serverless_endpoint : null
# }

# output "redshift_cluster_endpoint" {
#   value = length(module.redshift_cluster) > 0 ? module.redshift_cluster[*].redshift_cluster_endpoint : null
# }

# output "aws_glue_crawler_output" {
#   value = aws_glue_crawler.redshift_crawler
# }
