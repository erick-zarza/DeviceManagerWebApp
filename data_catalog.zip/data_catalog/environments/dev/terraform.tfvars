project                                 = "edp"
product                                 = "migration"
env_type                                = "dev"
redshift_type                           = "redshift-cluster"
master_user                             = "edpadmin"
master_password                         = "Adfalj#bla1h!afodif"
subnet_configs                          = ["dev"]
vpc_name                                = "vpc-093d08828aa097f03"
node_type                               = "ra3.4xlarge"
cluster_type                            = "multi-node"
publicly_accessible                     = false
number_of_nodes                         = 2
apply_immediately                       = false
availability_zone_relocation_enabled    = true
encrypted                               = true
skip_final_snapshot                     = true
ip_protocol                             = "tcp"
from_port                               = 5439
to_port                                 = 5439
redshift_serverless_base_capacity       = 32 // 32 RPUs to 512 RPUs in units of 8 (32,40,48...512)
redshift_serverless_publicly_accessible = false
qc_cidr_blocks = [
  "192.168.0.0/16",
  "10.0.0.0/8",
  "172.16.0.0/12",
  "199.106.96.0/19",
  "129.46.0.0/16"
]
subnet_configs_redshift = [
  {
    id           = "subnet-05a88156c51b83062"
    cidr_block   = "10.155.73.0/27"
    name         = "edp-dev PrivateDB A"
    routeTableId = "rtb-0c84559dc6509d825"
  },
  {
    id           = "subnet-0ad86bf76563a753c"
    cidr_block   = "10.155.73.32/27"
    name         = "edp-dev PrivateDB B"
    routeTableId = "rtb-0c84559dc6509d825"
  }
]
